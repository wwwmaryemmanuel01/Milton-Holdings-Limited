# Milton Financials — starter project

This starter preserves your uploaded website as `public/index.html` and adds a small
Node.js/Express server for deployment.

## What is included
- `public/index.html`: your original uploaded frontend, preserved without edits.
- `server.js`: web server and `/api/health` endpoint.
- `package.json`: Node dependencies and start command.
- `.env.example`: names of required server environment variables.
- `supabase/README.md`: safe next steps for connecting to your existing database.

## Run locally
1. Install Node.js 20 or later.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env` and fill in your own values locally.
4. Run `npm start`.
5. Open `http://localhost:3000` and `http://localhost:3000/api/health`.

The current frontend still uses browser storage for application data. This starter does NOT
yet migrate loan/customer data to Supabase or change the login flow. That integration must
be done after reviewing the existing Supabase schema and agreeing on the authentication
approach.

## Deploy to Railway
- Upload/push this project to a private GitHub repository, then deploy that repository on Railway.
- Railway should use `npm start` automatically.
- Add `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` under Railway's Variables settings.
- Never put the service-role key in `public/index.html`, frontend JavaScript, or a public repository.

## Important safety note
Do not run destructive SQL, reset the project, or delete existing tables. Review the current
schema first so the current administrator and any existing data are preserved.
