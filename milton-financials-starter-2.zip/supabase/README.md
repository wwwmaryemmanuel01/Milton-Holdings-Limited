# Supabase database notes

The existing Supabase project/database must be preserved.

No schema-changing SQL migration is included yet because the existing tables and columns
must be inspected before creating or altering anything. This prevents accidental loss or
duplication of your existing administrator account and records.

Next database step:
1. Open the existing Supabase project.
2. Open SQL Editor and inspect the current tables/schema.
3. Share a screenshot or a schema-only export (no passwords, API secrets, or customer data).
4. We will prepare a compatible migration only after reviewing the actual schema.
